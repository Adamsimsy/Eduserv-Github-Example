﻿function scDesignerFixSize() {
  if (!scForm.browser.isIE) {
    scForm.browser.initializeFixsizeElements(true);
  }
}